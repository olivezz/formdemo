module.exports = function () {

    var config = {

            indexFile: './src/index.html',
            jsFiles: [
                'src/app/**/*.js',
                '!src/app/**/*.spec.js'
            ],
            filesToInject:[
                './src/app/**/*.js',
                '!./src/app/**/*.spec.js',
                './src/assets/css/main.css'
            ],
            SASS: [
                /* first 3 files must in order */
                './src/sass/_colors.scss',
                './src/sass/_marginpadding.scss',
                './src/sass/_typography.scss',
                './src/sass/_layout.scss',
                './src/sass/styles.scss',
                './src/app/**/*.scss'
            ]
        }
        ;
    return config;
};
