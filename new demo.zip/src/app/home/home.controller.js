(function () {
    'use strict';

    angular.module('demo').controller('HomeCtrl', HomeCtrl);

    /* @ngInject */
    function HomeCtrl() {
        /* jshint validthis: true */



    }
})();
